package modelo;

public class Compartida extends Habitacion
{
	public Compartida(double costoBase)
	{
		super(costoBase);
	}
}
