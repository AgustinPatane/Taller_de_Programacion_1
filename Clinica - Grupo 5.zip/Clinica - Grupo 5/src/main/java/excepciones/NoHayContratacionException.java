package excepciones;

public class NoHayContratacionException extends ImposibleCrearMedicoException
{

	public NoHayContratacionException(String arg0)
	{
		super(arg0);
	}

}
