package excepciones;

public class ImposibleCrearMedicoException extends Exception
{

	public ImposibleCrearMedicoException(String arg0)
	{
		super(arg0);
	}

}
